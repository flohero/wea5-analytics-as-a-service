export enum LogType {
  Trace = "Trace",
  Warning = "Warning",
  Error = "Error"
}
