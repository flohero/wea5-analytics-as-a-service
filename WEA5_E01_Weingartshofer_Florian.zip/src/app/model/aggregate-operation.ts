export enum AggregateOperation {
  Min = 'Min',
  Max = 'Max',
  Sum = 'Sum',
  Average = 'Average',
  CurrentValue = 'CurrentValue'
}
