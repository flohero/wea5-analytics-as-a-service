export interface Client {
  id: number
  appKey: string
}
