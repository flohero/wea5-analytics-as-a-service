export enum DetectorType {
  Interval = 'Interval',
  MinMax = 'MinMax'
}
