export interface Action {
  id: number
  type: string
  endpoint: string
}
