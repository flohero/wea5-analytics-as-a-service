export enum MetricType {
  Counter = "Counter",
  Measurement = "Measurement"
}
