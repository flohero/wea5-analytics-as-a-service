export interface Timespan {
  hours: number
  minutes: number
  seconds: number
}
