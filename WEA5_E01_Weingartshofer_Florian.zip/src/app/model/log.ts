export interface Log {
  id: number
  name: string
  type: string
  instanceId: string
  createdAt: Date
  message: string
}
