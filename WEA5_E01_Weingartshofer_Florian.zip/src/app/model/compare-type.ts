export enum CompareType {
  Smaller = 'Smaller',
  Greater = 'Greater'
}
