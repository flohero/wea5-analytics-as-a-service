export interface MinMaxDetector {
  id: number
  lowerThreshold: number
  upperThreshold: number
  maxHits: number
}
