export interface IntervalDetector {
  id: number
  compareType: string
  aggregateOperation: string
  threshold: number
}
