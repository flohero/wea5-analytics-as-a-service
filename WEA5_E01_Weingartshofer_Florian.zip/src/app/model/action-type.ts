export enum ActionType {
  Email = 'Email',
  Webhook = 'Webhook'
}
