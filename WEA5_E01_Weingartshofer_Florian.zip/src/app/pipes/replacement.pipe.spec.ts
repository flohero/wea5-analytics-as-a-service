import {ReplacementPipe} from './replacement.pipe';

describe('ReplacementPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplacementPipe();
    expect(pipe).toBeTruthy();
  });
});
