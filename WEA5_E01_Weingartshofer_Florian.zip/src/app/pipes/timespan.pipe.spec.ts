import {TimespanPipe} from './timespan.pipe';

describe('TimespanPipe', () => {
  it('create an instance', () => {
    const pipe = new TimespanPipe();
    expect(pipe).toBeTruthy();
  });
});
